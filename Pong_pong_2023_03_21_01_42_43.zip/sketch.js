//Caracteristicas bolinha
let xBolinha = 300
let yBolinha = 200
let dBolinha = 30
let rBolinha = dBolinha/2

//Movimentacao bolinha
let velocidadeXBolinha = 6
let velocidadeYBolinha = 6

//Caracteristicas raquete
let xRaquete = 5
let yRaquete = 155
let cRaquete = 10
let aRaquete = 90
let colidiu = false;

//Caracteristicas raquete adv
let xRaqueteb = 585
let yRaqueteb = 155
let velYOponente;

//pontos
let meusPontos = 0;
let oponentePontos = 0;

//sons
let raquetada;
let ponto;

//vitoria
let euVenci;
let botVenceu;
let jogoAcabou;

function preload(){
  raquetada = loadSound("raquetada.mp3")
  ponto = loadSound("ponto.mp3")
}


function setup() {
  createCanvas(600, 400);
}

function draw() {
  background(0);
  mostraBolinha();
  movimentaBolinha();  
  verificaColisao();
  mostraRaquete(xRaquete, yRaquete);
  movimentaMinhaRaquete();
  mostraRaquete(xRaqueteb, yRaqueteb);
  colisaoMinhaRaqueteBiblioteca(xRaquete, yRaquete);
  //movimentaRaqueteOponente();
  colisaoMinhaRaqueteBiblioteca(xRaqueteb, yRaqueteb);
  incluiPlacar();
  pontuacao();
  pontuacaoInimiga();
  gameover();
  vitoria();
  derrota();
  derrotaAff();
  multiplayer();
  }

function mostraBolinha() {
  circle(xBolinha, yBolinha, dBolinha);
  
}

function movimentaBolinha() {
  xBolinha += velocidadeXBolinha;
  yBolinha += velocidadeYBolinha; 
}  
function verificaColisao(){
  if(xBolinha > width+ -rBolinha || 
    xBolinha < rBolinha){
    velocidadeXBolinha *= -1;
  } 
  if(yBolinha > height+ -rBolinha||
    yBolinha < rBolinha){
    velocidadeYBolinha *= -1  
  } 
}  

function mostraRaquete(x,y){
  rect(x,y, cRaquete, aRaquete)
  
}
function movimentaMinhaRaquete(){
  if (keyIsDown(87)){
    yRaquete -= 10
  }
  if (keyIsDown(83)){
    yRaquete += 10
  }
}
function colisaoMinhaRaqueteBiblioteca(x,y){
  colidiu = collideRectCircle(x,y, cRaquete, aRaquete, xBolinha, yBolinha, rBolinha)
  if (colidiu){
    velocidadeXBolinha *= -1;
    raquetada.play();
  }
}
function movimentaRaqueteOponente(){
  velYOponente = yBolinha - yRaqueteb - cRaquete/2-30;
  yRaqueteb += velYOponente
}

function incluiPlacar(){
  textAlign(CENTER);
  textSize(20);
  fill(color(186,85,211))
  rect(175, 9, 50, 20, 20)
  fill(255)
  text(meusPontos, 200, 26)
  fill(color(186,85,211))
  rect(375, 9, 50, 20, 20)
  fill(255)
  text(oponentePontos, 400, 26)
}
function pontuacao (){
  if (xBolinha - rBolinha < 1){
    oponentePontos += 1;
    ponto.play();
  }
}
function pontuacaoInimiga (){
  if (xBolinha + rBolinha > 599){
    meusPontos += 1
    ponto.play();
} 
}
function gameover(){
  if (meusPontos > 9 || oponentePontos > 9){
    xBolinha = 300
    yBolinha = 200
    if (meusPontos > 9) {
      euVenci = true
      }
    }
}
function derrotaAff(){
  if (oponentePontos > 9){
      botVenceu = true
}
}

function vitoria(){
  fill(255)
  textSize(18)
if (euVenci == true){
  text("Parabéns! Você venceu!", 300, 300) 
} 
}
function derrota(){
  fill(255)
  textSize(18)
if (botVenceu == true) {
    text("Que pena! Você perdeu!.", 300, 300)
}

  }
function multiplayer(){
  if (keyIsDown(UP_ARROW)){
    yRaqueteb -= 10
  }
  if (keyIsDown(DOWN_ARROW)){
    yRaqueteb += 10
  }
}

